'use strict';
// Ingestion: store evidence idempotently, match it to a client, group it into deliverables, and
// propose ledger suggestions for a reviewer. Nothing here ever posts a ledger event: points move
// only when a consultant approves a suggestion (see review.js).
//
// SECURITY: task and email content is untrusted evidence. It is pattern-matched for signals and
// displayed (escaped) to reviewers. It is never interpreted as instructions, and any text that
// looks like instructions is flagged for the reviewer.
const crypto = require('node:crypto');
const { tx, audit, nowIso } = require('./db');
const { activeContract } = require('./ledger');
const { findItem, matchByText } = require('./menu');
const { fetchClickUp } = require('./adapters/clickup');
const { fetchOutlook } = require('./adapters/outlook');

const INTERNAL_DOMAINS = (process.env.INTERNAL_EMAIL_DOMAINS || 'leadg2.com').split(',').map((d) => d.trim().toLowerCase());
const hash = (v) => crypto.createHash('sha256').update(typeof v === 'string' ? v : JSON.stringify(v)).digest('hex');
const domainOf = (email) => String(email || '').split('@')[1] || '';

// ---------------------------------------------------------------- client matching
function mappingsFor(db, clientId) {
  return db.prepare('SELECT * FROM source_mappings WHERE client_id = ?').all(clientId);
}

function matchRecord(db, rec) {
  if (rec.source_type === 'clickup_task') {
    const byList = db.prepare(`SELECT * FROM source_mappings WHERE source_type='clickup_list' AND value = ?`).get(rec.data.list_id || '');
    const bySpace = db.prepare(`SELECT * FROM source_mappings WHERE source_type='clickup_space' AND value = ?`).get(rec.data.space_id || '');
    const m = byList || bySpace;
    if (m) return { status: 'matched', clientId: m.client_id, scope: byList ? byList.scope : bySpace.scope, reason: `Mapped ClickUp ${byList ? 'list' : 'space'} ${m.label || m.value}` };
    return { status: 'ignored', reason: 'ClickUp location is not mapped to a client' };
  }
  // Outlook: participants vs explicit address/domain mappings.
  const external = rec.data.participants.filter((p) => !INTERNAL_DOMAINS.includes(domainOf(p)));
  const hits = new Map();
  for (const p of external) {
    const m = db.prepare(`SELECT * FROM source_mappings WHERE (source_type='email_address' AND lower(value)=?)
                          OR (source_type='email_domain' AND lower(value)=?) ORDER BY source_type='email_address' DESC`).get(p, domainOf(p));
    if (m && !hits.has(m.client_id)) hits.set(m.client_id, m);
  }
  if (hits.size === 1) {
    const [m] = hits.values();
    return { status: 'matched', clientId: m.client_id, scope: m.scope, reason: `Participant matches mapped ${m.source_type.replace('_', ' ')} ${m.value}` };
  }
  if (hits.size > 1) {
    return { status: 'uncertain', candidates: [...hits.keys()], reason: 'Participants match more than one client' };
  }
  const text = `${rec.title}\n${rec.body}`.toLowerCase();
  const candidates = db.prepare('SELECT id, name, aliases FROM clients').all()
    .filter((c) => [c.name, ...JSON.parse(c.aliases)].some((a) => a && text.includes(a.toLowerCase()))).map((c) => c.id);
  if (candidates.length) return { status: 'uncertain', candidates, reason: 'Mentions a client name but no participant matches a mapped address or domain' };
  return { status: 'ignored', reason: 'No mapped participant' };
}

// ---------------------------------------------------------------- idempotent upsert
function upsertRecord(db, rec, match) {
  const contentHash = hash({ t: rec.title, s: rec.status, b: rec.body, d: rec.data, o: rec.occurred_at });
  const linkedTask = rec.source_type === 'outlook_message' ? findTaskRef(`${rec.title}\n${rec.body}`) : null;
  const existing = db.prepare('SELECT * FROM source_records WHERE source_type = ? AND external_id = ?').get(rec.source_type, rec.external_id);
  if (existing) {
    if (existing.content_hash === contentHash) {
      db.prepare('UPDATE source_records SET last_seen_at = ? WHERE id = ?').run(nowIso(), existing.id);
      return { id: existing.id, outcome: 'unchanged' };
    }
    // Keep a reviewer's manual client resolution if the automatic match is still not certain.
    const keepManual = existing.match_status === 'matched' && match.status !== 'matched';
    db.prepare(`UPDATE source_records SET title=?, status=?, author=?, body=?, data=?, url=?, occurred_at=?, thread_id=?, linked_task_id=?,
        content_hash=?, last_seen_at=?, client_id=?, match_status=?, match_candidates=?, match_reason=?, scope=? WHERE id=?`)
      .run(rec.title, rec.status, rec.author, rec.body, JSON.stringify(rec.data), rec.url, rec.occurred_at, rec.thread_id, linkedTask,
        contentHash, nowIso(),
        keepManual ? existing.client_id : (match.clientId ?? null),
        keepManual ? existing.match_status : match.status,
        JSON.stringify(match.candidates || []), keepManual ? existing.match_reason : match.reason,
        keepManual ? existing.scope : (match.scope || 'points'), existing.id);
    return { id: existing.id, outcome: 'updated' };
  }
  const r = db.prepare(`INSERT INTO source_records (source_type, external_id, client_id, match_status, match_candidates, match_reason, scope,
      thread_id, linked_task_id, occurred_at, url, title, status, author, body, data, content_hash)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(rec.source_type, rec.external_id, match.clientId ?? null, match.status,
    JSON.stringify(match.candidates || []), match.reason, match.scope || 'points', rec.thread_id, linkedTask, rec.occurred_at, rec.url,
    rec.title, rec.status, rec.author, rec.body, JSON.stringify(rec.data), contentHash);
  return { id: Number(r.lastInsertRowid), outcome: 'new' };
}

function findTaskRef(text) {
  const m = /app\.clickup\.com\/t\/([a-z0-9]+)/i.exec(text) || /\bCU-([a-z0-9]{5,})\b/i.exec(text);
  return m ? m[1].toLowerCase() : null;
}

// ---------------------------------------------------------------- grouping
// One deliverable = one ClickUp task (subtasks roll up to the parent) plus the email threads that
// reference it. Threads with no task reference form their own group. Reviewer merges override both.
function regroup(db, clientId) {
  const recs = db.prepare(`SELECT * FROM source_records WHERE client_id = ? AND match_status = 'matched'`).all(clientId);
  const threadTask = new Map();
  for (const r of recs) if (r.source_type === 'outlook_message' && r.linked_task_id && r.thread_id && !threadTask.has(r.thread_id)) threadTask.set(r.thread_id, r.linked_task_id);
  const upd = db.prepare('UPDATE source_records SET group_key = ? WHERE id = ?');
  for (const r of recs) {
    let key;
    if (r.group_override) key = r.group_override;
    else if (r.source_type === 'clickup_task') key = `clickup:${(JSON.parse(r.data).parent_id || r.external_id).toLowerCase()}`;
    else if (r.linked_task_id) key = `clickup:${r.linked_task_id}`;
    else if (r.thread_id && threadTask.has(r.thread_id)) key = `clickup:${threadTask.get(r.thread_id)}`;
    else key = `outlook:${r.thread_id || r.external_id}`;
    if (key !== r.group_key) upd.run(key, r.id);
  }
}

// ---------------------------------------------------------------- signals
const INJECTION = /(ignore (all |any )?(previous|prior|above) instructions|disregard (the )?(rules|instructions)|system prompt|you are (an? )?(ai|assistant|model)|as an ai|mark .{0,40} as (used|approved|complete)|(add|credit|deduct|set) \d+ points)/i;

function latestReply(body) {
  // Ignore quoted history so an old "approved" further down a thread isn't re-counted.
  const cut = String(body || '').split(/\n(?:-{2,}\s*Original Message|From: .+|On .{5,80} wrote:)/i)[0];
  return cut.split('\n').filter((l) => !l.trim().startsWith('>')).join('\n');
}

function clickupSignal(status) {
  const s = String(status || '').toLowerCase();
  if (/cancel/.test(s)) return 'canceled';
  if (/^(complete|completed|closed|done|delivered)$/.test(s)) return 'completed';
  if (/approved/.test(s)) return 'approved';
  if (/(progress|review|scheduled|active|working)/.test(s)) return 'in_progress';
  return 'requested';
}

function emailSignals(text) {
  const t = text.toLowerCase();
  const out = [];
  if (/\b(cancel|cancell?ed|hold off|no longer need|scrap (it|this)|put (it|this|that) on hold)\b/.test(t)) out.push('canceled');
  if (/\b(is live|went live|now live|launched|delivered|completed?|wrapped up|all done|finished)\b/.test(t)) out.push('completed');
  if (/\b(approved?|go ahead|please proceed|green light|signed off|sign-off|let'?s do it|you have the go)\b/.test(t)) out.push('approved');
  if (/\b(instead of|scope change|change (the|of) scope|revise the scope|switch (it )?to|expand(ing)? the scope)\b/.test(t)) out.push('changed');
  if (/\b(can you|could you|would you|we'?d like|we need|interested in|request(ing)?|wondering if)\b/.test(t)) out.push('requested');
  return out;
}

function recordSignals(db, clientId, r) {
  if (r.source_type === 'clickup_task') return { signals: [clickupSignal(r.status)], fromClient: false };
  const clientDomains = mappingsFor(db, clientId).filter((m) => m.source_type === 'email_domain').map((m) => m.value.toLowerCase());
  const clientAddrs = mappingsFor(db, clientId).filter((m) => m.source_type === 'email_address').map((m) => m.value.toLowerCase());
  const from = (r.author || '').toLowerCase();
  const fromClient = clientAddrs.includes(from) || clientDomains.includes(domainOf(from));
  return { signals: emailSignals(`${r.title}\n${latestReply(r.body)}`), fromClient };
}

const fmtDate = (iso) => String(iso || '').slice(0, 10);
const excerpt = (s, n = 140) => { const t = String(s || '').replace(/\s+/g, ' ').trim(); return t.length > n ? `${t.slice(0, n)}…` : t; };
const cleanSubject = (s) => String(s || '').replace(/^\s*((re|fw|fwd)\s*:\s*)+/i, '').trim();

// ---------------------------------------------------------------- suggestions
function evaluateGroup(db, clientId, groupKey) {
  const contract = activeContract(db, clientId);
  const recs = db.prepare(`SELECT * FROM source_records WHERE client_id = ? AND match_status='matched' AND group_key = ? ORDER BY occurred_at`).all(clientId, groupKey);
  if (!recs.length) return null;
  const item = db.prepare('SELECT * FROM work_items WHERE client_id = ? AND group_key = ?').get(clientId, groupKey);
  const tasks = recs.filter((r) => r.source_type === 'clickup_task');
  const emails = recs.filter((r) => r.source_type === 'outlook_message');
  const task = tasks.find((t) => !JSON.parse(t.data).parent_id) || tasks[0];
  const taskData = task ? JSON.parse(task.data) : {};

  const flags = new Set();
  const lines = [];
  const evidence = [];
  const has = { requested: false, approved: false, clientApproved: false, in_progress: false, completed: false, canceled: false, clientCanceled: false, changed: false };
  let taskSignal = null;
  const emailSigs = new Set();
  const sigDate = {}; // latest date each signal was seen

  for (const r of recs) {
    const { signals, fromClient } = recordSignals(db, clientId, r);
    evidence.push({ id: r.id, signal: signals.join(',') || 'mention' });
    if (r.source_type === 'clickup_task') {
      if (r === task) taskSignal = signals[0];
      lines.push(`ClickUp task "${r.title}" is ${r.status || 'unknown'} (updated ${fmtDate(r.occurred_at)}).`);
    } else {
      signals.forEach((s) => emailSigs.add(s));
      lines.push(`${fromClient ? 'Client' : 'Internal'} email from ${r.author} on ${fmtDate(r.occurred_at)}: "${excerpt(latestReply(r.body))}"`);
    }
    const when = r.source_type === 'clickup_task' && signals[0] === 'completed' ? (JSON.parse(r.data).date_closed || r.occurred_at) : r.occurred_at;
    for (const s of signals) {
      has[s] = true;
      if (!sigDate[s] || when > sigDate[s]) sigDate[s] = when;
      if (s === 'approved' && fromClient) has.clientApproved = true;
      if (s === 'canceled' && fromClient) has.clientCanceled = true;
    }
    if (INJECTION.test(`${r.title}\n${r.body}`)) flags.add('embedded_instructions');
    if (r.scope === 'consulting') flags.add('may_be_included_in_consulting');
    if (r.scope === 'project') flags.add('may_be_fixed_scope_project');
  }
  const allText = recs.map((r) => `${r.title}\n${r.body}`).join('\n').toLowerCase();
  if (/\b(monthly (consulting|strategy)|consulting call|strategy call|retainer|proactive consulting)\b/.test(allText)) flags.add('may_be_included_in_consulting');
  if (/\b(fixed[- ]scope|statement of work|\bsow\b|project phase|phase \d)\b/.test(allText) || (taskData.tags || []).includes('project')) flags.add('may_be_fixed_scope_project');
  if ((taskData.tags || []).includes('consulting')) flags.add('may_be_included_in_consulting');

  // Sources disagree?
  if (has.completed && has.canceled) flags.add('sources_disagree');
  if (taskSignal && taskSignal !== 'canceled' && emailSigs.has('canceled')) flags.add('sources_disagree');
  if (taskSignal === 'canceled' && (emailSigs.has('approved') || emailSigs.has('completed'))) flags.add('sources_disagree');
  if (taskSignal && taskSignal !== 'completed' && emailSigs.has('completed') && !emailSigs.has('canceled')) flags.add('sources_disagree');
  if (!tasks.length) flags.add('email_only');

  const isSupport = recs.some((r) => r.scope === 'support_hours');
  const title = item ? item.title : (task ? task.title : cleanSubject(emails[0].title));

  // Decide what to propose.
  let action = null;
  if (isSupport) {
    action = 'support_hours';
    flags.delete('may_be_included_in_consulting');
    if (!has.completed) flags.add('not_yet_completed');
  } else if (item) {
    if (['used', 'canceled'].includes(item.state)) action = has.changed ? 'change' : null;
    else if (has.clientCanceled || (has.canceled && !has.completed)) action = 'cancel';
    else if (has.completed) action = 'complete';
    else if (has.changed) action = 'change';
    else if (item.state === 'forecast' && (has.clientApproved || has.approved)) action = 'approve';
  } else if (has.canceled && !has.completed && !has.approved) {
    action = null; // requested then canceled before anything was approved: nothing to book
  } else if (has.completed) action = 'complete';
  else if (has.clientApproved) action = 'approve';
  else if (has.approved || has.in_progress || has.requested || recs.length) action = 'forecast';

  if (!action) return null;
  if (!isSupport && !item && (action === 'complete' || action === 'approve') && !has.clientApproved) flags.add('no_client_approval_evidence');
  if (has.changed) flags.add('scope_changed');

  // Point amount from the client's menu version.
  let menu = null, proposed = null, pmin = null, pmax = null, hours = null;
  if (isSupport) {
    hours = taskData.hours ?? null;
    if (hours == null) flags.add('hours_unclear');
    lines.push(`Mapped to the HubSpot support-hours bank (tracked in hours, not points).`);
  } else if (item && action !== 'change') {
    proposed = item.points;
    lines.push(`Existing ledger entry #${item.id} (${item.state}, ${item.points} pts from menu ${item.menu_item_code || 'n/a'}). The same points move; nothing is charged twice.`);
  } else {
    menu = (taskData.menu_code && findItem(db, clientId, taskData.menu_code)) || matchByText(db, clientId, `${title}\n${allText}`);
    if (taskData.menu_code && !findItem(db, clientId, taskData.menu_code)) flags.add('menu_item_not_on_client_menu');
    if (menu) {
      pmin = menu.points_min; pmax = menu.points_max;
      const ver = db.prepare('SELECT code FROM menu_versions WHERE id = ?').get(contract.menu_version_id).code;
      if (pmin === pmax) {
        proposed = pmin;
        lines.push(`Menu ${ver} · ${menu.code} "${menu.name}" = ${pmin} pts.`);
        if (taskData.points != null && taskData.points !== pmin) { flags.add('sources_disagree'); lines.push(`ClickUp Points field says ${taskData.points}.`); }
      } else {
        flags.add('points_range_confirm');
        lines.push(`Menu ${ver} · ${menu.code} "${menu.name}" is a range: ${pmin}–${pmax} pts. Reviewer must confirm the amount.`);
        if (taskData.points != null) {
          lines.push(`ClickUp Points field suggests ${taskData.points}.`);
          if (taskData.points < pmin || taskData.points > pmax) flags.add('sources_disagree');
          else proposed = taskData.points; // pre-filled, but the flag still asks the reviewer to confirm
        }
      }
      if (menu.notes) lines.push(`Menu note: ${menu.notes}`);
    } else {
      flags.add('point_cost_unclear');
      lines.push('No matching item on this client\'s service menu. Reviewer must choose the item and amount.');
    }
    if (item && action === 'change') lines.unshift(`Scope change on existing entry #${item.id} (${item.state}, ${item.points} pts).`);
  }
  if (flags.has('embedded_instructions')) lines.push('⚠ Source text contains instruction-like language. It was treated as evidence only and not acted on.');

  const evidenceHash = hash(recs.map((r) => [r.id, r.content_hash]));
  const dateFor = { complete: sigDate.completed, cancel: sigDate.canceled, approve: sigDate.approved, support_hours: sigDate.completed };
  const evidenceDate = fmtDate(dateFor[action] || recs[recs.length - 1].occurred_at);
  return { action, evidenceDate, title, item, menu, proposed, pmin, pmax, hours, flags: [...flags], rationale: lines.join('\n'), evidence, evidenceHash };
}

const STAGE = { forecast: 0, approve: 1, change: 1, support_hours: 1, cancel: 2, complete: 2 };

function generateSuggestions(db, clientId) {
  return tx(db, () => {
    regroup(db, clientId);
    const groups = db.prepare(`SELECT DISTINCT group_key FROM source_records WHERE client_id = ? AND match_status='matched' AND group_key IS NOT NULL`).all(clientId);
    let created = 0, refreshed = 0;
    for (const { group_key: gk } of groups) {
      const ev = evaluateGroup(db, clientId, gk);
      if (!ev) continue;
      const existing = db.prepare('SELECT * FROM suggestions WHERE client_id = ? AND group_key = ? AND action = ?').get(clientId, gk, ev.action);
      let sid;
      if (existing) {
        if (existing.status !== 'open' || existing.evidence_hash === ev.evidenceHash) continue; // resolved suggestions are never resurrected
        if (existing.edited) {
          db.prepare(`UPDATE suggestions SET evidence_date=?, rationale=?, flags=?, evidence_hash=?, updated_at=? WHERE id=?`)
            .run(ev.evidenceDate, ev.rationale, JSON.stringify(ev.flags), ev.evidenceHash, nowIso(), existing.id);
        } else {
          db.prepare(`UPDATE suggestions SET title=?, work_item_id=?, menu_item_code=?, proposed_points=?, points_min=?, points_max=?, proposed_hours=?,
              evidence_date=?, rationale=?, flags=?, evidence_hash=?, updated_at=? WHERE id=?`)
            .run(ev.title, ev.item ? ev.item.id : null, ev.menu ? ev.menu.code : (ev.item ? ev.item.menu_item_code : null), ev.proposed, ev.pmin, ev.pmax,
              ev.hours, ev.evidenceDate, ev.rationale, JSON.stringify(ev.flags), ev.evidenceHash, nowIso(), existing.id);
        }
        sid = existing.id; refreshed++;
      } else {
        const r = db.prepare(`INSERT INTO suggestions (client_id, group_key, action, work_item_id, title, menu_item_code, proposed_points, points_min, points_max,
            proposed_hours, evidence_date, rationale, flags, evidence_hash) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
          .run(clientId, gk, ev.action, ev.item ? ev.item.id : null, ev.title, ev.menu ? ev.menu.code : (ev.item ? ev.item.menu_item_code : null),
            ev.proposed, ev.pmin, ev.pmax, ev.hours, ev.evidenceDate, ev.rationale, JSON.stringify(ev.flags), ev.evidenceHash);
        sid = Number(r.lastInsertRowid); created++;
        // Newer evidence supersedes earlier-stage open suggestions for the same deliverable.
        for (const old of db.prepare(`SELECT * FROM suggestions WHERE client_id=? AND group_key=? AND status='open' AND id != ?`).all(clientId, gk, sid)) {
          if (STAGE[old.action] <= STAGE[ev.action]) {
            db.prepare(`UPDATE suggestions SET status='dismissed', resolved_by='system', resolved_at=?, resolution_note=? WHERE id=?`)
              .run(nowIso(), `Superseded by suggestion #${sid} (newer evidence)`, old.id);
          }
        }
      }
      db.prepare('DELETE FROM suggestion_evidence WHERE suggestion_id = ?').run(sid);
      const ins = db.prepare('INSERT OR IGNORE INTO suggestion_evidence (suggestion_id, source_record_id, signal) VALUES (?,?,?)');
      for (const e of ev.evidence) ins.run(sid, e.id, e.signal);
    }
    return { created, refreshed };
  });
}

// ---------------------------------------------------------------- sync orchestration
function lastSuccess(db, clientId, source) {
  return db.prepare(`SELECT * FROM sync_runs WHERE client_id=? AND source=? AND status='success' ORDER BY id DESC LIMIT 1`).get(clientId, source);
}

async function syncSource(db, { clientId, source, adapter, actor = 'system' }) {
  const contract = activeContract(db, clientId);
  const client = db.prepare('SELECT * FROM clients WHERE id = ?').get(clientId);
  const prev = lastSuccess(db, clientId, source);
  // Re-read a 1-day overlap: safe because imports are idempotent, and it covers clock skew.
  const overlap = prev ? new Date(Date.parse(prev.started_at) - 86400000).toISOString() : null;
  const opening = contract.opening_balance_date ? new Date(`${contract.opening_balance_date}T00:00:00Z`).toISOString() : null;
  const since = [opening, overlap].filter(Boolean).sort().pop() || null;
  const run = db.prepare(`INSERT INTO sync_runs (client_id, source, mode, started_at, status, since) VALUES (?,?,?,?, 'running', ?)`)
    .run(clientId, source, adapter.mode || 'unknown', nowIso(), since);
  const runId = Number(run.lastInsertRowid);
  try {
    const ctx = { mappings: mappingsFor(db, clientId), aliases: [client.name, ...JSON.parse(client.aliases)], since };
    const records = source === 'clickup' ? await fetchClickUp(adapter, ctx) : await fetchOutlook(adapter, ctx);
    const stats = { seen: 0, new: 0, updated: 0 };
    const touched = new Set([clientId]);
    tx(db, () => {
      for (const rec of records) {
        if (opening && rec.occurred_at < opening) continue; // before the reconciled opening balance
        stats.seen++;
        const match = matchRecord(db, rec);
        if (match.status === 'ignored') continue; // unrelated mail is not stored
        if (match.status === 'matched' && match.clientId !== clientId) touched.add(match.clientId);
        const res = upsertRecord(db, rec, match);
        if (res.outcome === 'new') stats.new++;
        if (res.outcome === 'updated') stats.updated++;
      }
    });
    for (const cid of touched) generateSuggestions(db, cid);
    db.prepare(`UPDATE sync_runs SET status='success', finished_at=?, records_seen=?, records_new=?, records_updated=? WHERE id=?`)
      .run(nowIso(), stats.seen, stats.new, stats.updated, runId);
    audit(db, { clientId, actor, action: `sync.${source}.success`, detail: stats });
    return { runId, status: 'success', ...stats };
  } catch (e) {
    const msg = String(e && e.message || e).slice(0, 500);
    db.prepare(`UPDATE sync_runs SET status='failed', finished_at=?, error=? WHERE id=?`).run(nowIso(), msg, runId);
    audit(db, { clientId, actor, action: `sync.${source}.failed`, reason: msg });
    return { runId, status: 'failed', error: msg };
  }
}

function syncStatus(db, clientId) {
  const out = {};
  for (const source of ['clickup', 'outlook', 'tracker']) {
    const ok = lastSuccess(db, clientId, source);
    const last = db.prepare('SELECT * FROM sync_runs WHERE client_id=? AND source=? ORDER BY id DESC LIMIT 1').get(clientId, source);
    const failures = db.prepare(`SELECT started_at, error FROM sync_runs WHERE client_id=? AND source=? AND status='failed' ORDER BY id DESC LIMIT 5`).all(clientId, source);
    out[source] = { last_success_at: ok ? ok.finished_at : null, last_run: last || null, recent_failures: failures };
  }
  return out;
}

// ---------------------------------------------------------------- uncertain match queue
function matchQueue(db) {
  return db.prepare(`SELECT id, source_type, external_id, title, author, occurred_at, url, match_candidates, match_reason, body
                     FROM source_records WHERE match_status = 'uncertain' ORDER BY occurred_at DESC`).all()
    .map((r) => ({ ...r, match_candidates: JSON.parse(r.match_candidates), body: excerpt(r.body, 600) }));
}

function resolveMatch(db, { recordId, clientId, actor, reason }) {
  return tx(db, () => {
    const r = db.prepare('SELECT * FROM source_records WHERE id = ?').get(recordId);
    if (!r) throw Object.assign(new Error('Record not found'), { status: 404 });
    if (clientId) {
      db.prepare(`UPDATE source_records SET client_id=?, match_status='matched', match_reason=? WHERE id=?`)
        .run(clientId, `Assigned by ${actor}${reason ? `: ${reason}` : ''}`, recordId);
      audit(db, { clientId, actor, action: 'match.assign', entity: 'source_record', entityId: recordId, reason });
      generateSuggestions(db, clientId);
    } else {
      db.prepare(`UPDATE source_records SET client_id=NULL, match_status='ignored', match_reason=? WHERE id=?`)
        .run(`Ignored by ${actor}${reason ? `: ${reason}` : ''}`, recordId);
      audit(db, { actor, action: 'match.ignore', entity: 'source_record', entityId: recordId, reason });
    }
  });
}

module.exports = { syncSource, syncStatus, generateSuggestions, regroup, matchQueue, resolveMatch, matchRecord, emailSignals, findTaskRef, INJECTION };
