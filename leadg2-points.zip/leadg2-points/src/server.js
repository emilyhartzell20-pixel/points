'use strict';
// HTTP server (no framework). Client isolation is enforced here: client-role routes never accept a
// client id from the request; they use the id bound to the authenticated user.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { openDb, audit, AppError } = require('./db');
const auth = require('./auth');
const ledger = require('./ledger');
const review = require('./review');
const ingest = require('./ingest');
const importer = require('./importer');
const admin = require('./admin');
const { clientDashboard } = require('./clientView');
const { menuForClient } = require('./menu');
const { SampleClickUp, LiveClickUp } = require('./adapters/clickup');
const { SampleOutlook, LiveOutlook } = require('./adapters/outlook');

const PUBLIC = path.join(__dirname, '..', 'public');
const COOKIE = 'lg2_session';

function defaultAdapters() {
  const live = process.env.CONNECTOR_MODE === 'live';
  return { clickup: live ? new LiveClickUp() : new SampleClickUp(), outlook: live ? new LiveOutlook() : new SampleOutlook() };
}

function parseCookies(h) {
  const out = {};
  for (const part of String(h || '').split(';')) { const i = part.indexOf('='); if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); }
  return out;
}

function send(res, status, body, headers = {}) {
  const isJson = typeof body !== 'string' && !Buffer.isBuffer(body);
  res.writeHead(status, {
    'Content-Type': isJson ? 'application/json; charset=utf-8' : headers['Content-Type'] || 'text/plain; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
    ...headers,
  });
  res.end(isJson ? JSON.stringify(body) : body);
}

async function readJson(req) {
  if (!/^application\/json/.test(req.headers['content-type'] || '')) throw new AppError(415, 'Expected application/json');
  let size = 0; const chunks = [];
  for await (const c of req) { size += c.length; if (size > 2e6) throw new AppError(413, 'Request too large'); chunks.push(c); }
  try { return chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}; } catch { throw new AppError(400, 'Invalid JSON'); }
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png' };
function serveStatic(res, file) {
  const p = path.join(PUBLIC, file);
  if (!p.startsWith(PUBLIC) || !fs.existsSync(p)) return send(res, 404, 'Not found');
  send(res, 200, fs.readFileSync(p), { 'Content-Type': MIME[path.extname(p)] || 'application/octet-stream' });
}

function createApp({ db, adapters = defaultAdapters(), secureCookies = process.env.NODE_ENV === 'production' } = {}) {
  const routes = [];
  const route = (method, pattern, role, handler) => {
    const keys = []; const re = new RegExp(`^${pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; })}$`);
    routes.push({ method, re, keys, role, handler });
  };
  const int = (v) => { const n = Number(v); if (!Number.isInteger(n)) throw new AppError(400, 'Bad id'); return n; };
  const clientExists = (id) => { if (!db.prepare('SELECT 1 FROM clients WHERE id = ?').get(id)) throw new AppError(404, 'Client not found'); return id; };
  const ownerOf = (table, id) => { const r = db.prepare(`SELECT client_id FROM ${table} WHERE id = ?`).get(id); if (!r) throw new AppError(404, 'Not found'); return r.client_id; };

  // ---- auth
  route('POST', '/api/login', null, async ({ req, res }) => {
    const { email, password } = await readJson(req);
    const s = auth.login(db, email, password);
    if (!s) throw new AppError(401, 'Email or password is incorrect');
    if (s.user.role === 'client') {
      const c = db.prepare('SELECT portal_enabled FROM clients WHERE id = ?').get(s.user.client_id);
      if (!c || !c.portal_enabled) { auth.logout(db, s.token); throw new AppError(403, 'Your dashboard is not available yet. Your LeadG2 consultant will let you know when it is ready.'); }
    }
    const cookie = `${COOKIE}=${encodeURIComponent(s.token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200${secureCookies ? '; Secure' : ''}`;
    send(res, 200, { user: s.user }, { 'Set-Cookie': cookie });
  });
  route('POST', '/api/logout', 'any', async ({ res, token }) => {
    auth.logout(db, token);
    send(res, 200, { ok: true }, { 'Set-Cookie': `${COOKIE}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0` });
  });
  route('GET', '/api/me', 'any', ({ res, user }) => send(res, 200, { user }));

  // ---- client (scope comes from the session ONLY)
  route('GET', '/api/client/dashboard', 'client', ({ res, user }) => {
    const c = db.prepare('SELECT portal_enabled FROM clients WHERE id = ?').get(user.client_id);
    if (!c || !c.portal_enabled) throw new AppError(403, 'Dashboard access has not been granted');
    send(res, 200, clientDashboard(db, user.client_id));
  });

  // ---- staff
  route('GET', '/api/staff/clients', 'staff', ({ res }) => {
    const rows = db.prepare('SELECT id, slug, name, portal_enabled, pilot FROM clients ORDER BY pilot DESC, name').all();
    send(res, 200, rows.map((c) => ({ ...c, open_suggestions: db.prepare(`SELECT COUNT(*) n FROM suggestions WHERE client_id=? AND status='open'`).get(c.id).n })));
  });
  route('GET', '/api/staff/clients/:id/overview', 'staff', ({ res, p }) => {
    const id = clientExists(int(p.id));
    const contract = ledger.activeContract(db, id);
    const menu = menuForClient(db, id);
    send(res, 200, {
      client: db.prepare('SELECT * FROM clients WHERE id = ?').get(id),
      contract, allocations: db.prepare('SELECT * FROM allocations WHERE contract_id = ?').all(contract.id),
      balance: ledger.balance(db, id), support_hours: ledger.supportHours(db, id),
      menu, sync: ingest.syncStatus(db, id),
      mappings: db.prepare('SELECT * FROM source_mappings WHERE client_id = ?').all(id),
      connector_mode: Object.fromEntries(Object.entries(adapters).map(([k, a]) => [k, a.mode])),
    });
  });
  route('GET', '/api/staff/clients/:id/suggestions', 'staff', ({ res, p, url }) =>
    send(res, 200, review.listSuggestions(db, clientExists(int(p.id)), url.searchParams.get('status') || 'open')));
  route('GET', '/api/staff/clients/:id/work-items', 'staff', ({ res, p }) => {
    const id = clientExists(int(p.id));
    const ev = db.prepare(`SELECT r.source_type, r.title, r.url FROM work_item_evidence we JOIN source_records r ON r.id = we.source_record_id WHERE we.work_item_id = ?`);
    send(res, 200, ledger.listItems(db, id).map((w) => ({ ...w, evidence: ev.all(w.id) })));
  });
  route('GET', '/api/staff/clients/:id/ledger', 'staff', ({ res, p }) => send(res, 200, ledger.listEvents(db, clientExists(int(p.id)))));
  route('GET', '/api/staff/clients/:id/audit', 'staff', ({ res, p }) =>
    send(res, 200, db.prepare('SELECT * FROM audit_log WHERE client_id = ? ORDER BY id DESC LIMIT 300').all(clientExists(int(p.id)))));
  route('GET', '/api/staff/clients/:id/preview', 'staff', ({ res, p, user }) => {
    const id = clientExists(int(p.id));
    audit(db, { clientId: id, actor: user.email, action: 'client_view.preview' });
    send(res, 200, clientDashboard(db, id));
  });
  route('POST', '/api/staff/clients/:id/portal', 'staff', async ({ req, res, p, user }) => {
    const id = clientExists(int(p.id)); const { enabled } = await readJson(req);
    db.prepare('UPDATE clients SET portal_enabled = ? WHERE id = ?').run(enabled ? 1 : 0, id);
    if (!enabled) db.prepare(`DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE client_id = ?)`).run(id);
    audit(db, { clientId: id, actor: user.email, action: enabled ? 'portal.grant' : 'portal.revoke' });
    send(res, 200, { portal_enabled: !!enabled });
  });
  route('POST', '/api/staff/clients/:id/sync', 'staff', async ({ req, res, p, user }) => {
    const id = clientExists(int(p.id)); const { source } = await readJson(req);
    const sources = source ? [source] : ['clickup', 'outlook'];
    const results = {};
    for (const s of sources) {
      if (!adapters[s]) throw new AppError(400, `Unknown source ${s}`);
      results[s] = await ingest.syncSource(db, { clientId: id, source: s, adapter: adapters[s], actor: user.email });
    }
    send(res, 200, results);
  });
  route('POST', '/api/staff/clients/:id/import', 'staff', async ({ req, res, p, user }) => {
    const id = clientExists(int(p.id)); const b = await readJson(req);
    send(res, 200, importer.importTracker(db, { clientId: id, csv: b.csv, actor: user.email, opening: !!b.opening, filename: b.filename }));
  });
  route('POST', '/api/staff/clients/:id/work-items', 'staff', async ({ req, res, p, user }) => {
    const id = clientExists(int(p.id)); const b = await readJson(req);
    send(res, 200, importer.manualEntry(db, { ...b, clientId: id, points: Number(b.points), actor: user.email }));
  });
  route('POST', '/api/staff/clients/:id/allocations', 'staff', async ({ req, res, p, user }) => {
    const id = clientExists(int(p.id)); const b = await readJson(req);
    send(res, 200, ledger.addAllocation(db, { clientId: id, kind: b.kind, points: Number(b.points), sourceRef: b.sourceRef, note: b.note, actor: user.email }));
  });
  // ---- service point menu
  route('GET', '/api/staff/menus', 'staff', ({ res }) => send(res, 200, admin.listMenus(db)));
  route('POST', '/api/staff/menus', 'staff', async ({ req, res, user }) => {
    const b = await readJson(req);
    send(res, 200, admin.createMenuVersion(db, { code: b.code, name: b.name, effectiveDate: b.effectiveDate, copyFromId: b.copyFromId ? int(b.copyFromId) : null, actor: user.email }));
  });
  route('POST', '/api/staff/menus/:vid', 'staff', async ({ req, res, p, user }) => {
    const b = await readJson(req);
    send(res, 200, admin.updateMenuVersion(db, { id: int(p.vid), name: b.name, effectiveDate: b.effectiveDate, actor: user.email }));
  });
  route('POST', '/api/staff/menus/:vid/items', 'staff', async ({ req, res, p, user }) => {
    const b = await readJson(req);
    send(res, 200, admin.saveMenuItem(db, { ...b, versionId: int(p.vid), itemId: b.itemId ? int(b.itemId) : null, actor: user.email }));
  });
  route('POST', '/api/staff/menus/:vid/items/:iid/delete', 'staff', async ({ res, p, user }) => {
    admin.deleteMenuItem(db, { versionId: int(p.vid), itemId: int(p.iid), actor: user.email }); send(res, 200, { ok: true });
  });
  route('POST', '/api/staff/clients/:id/menu', 'staff', async ({ req, res, p, user }) => {
    const id = clientExists(int(p.id)); const b = await readJson(req);
    send(res, 200, admin.assignMenu(db, { clientId: id, versionId: int(b.versionId), actor: user.email }));
  });

  // ---- client logins (invite links: the client chooses their own password)
  const inviteLink = (req, token) => {
    const base = process.env.PUBLIC_URL || `${secureCookies ? 'https' : 'http'}://${req.headers.host}`;
    return `${base.replace(/\/$/, '')}/setup#t=${token}`; // fragment: never sent to servers or logs
  };
  route('GET', '/api/staff/clients/:id/users', 'staff', ({ res, p }) => send(res, 200, admin.listClientUsers(db, clientExists(int(p.id)))));
  route('POST', '/api/staff/clients/:id/users', 'staff', async ({ req, res, p, user }) => {
    const id = clientExists(int(p.id)); const b = await readJson(req);
    const r = admin.inviteClientUser(db, { clientId: id, email: b.email, name: b.name, actor: user.email });
    send(res, 200, { userId: r.userId, link: inviteLink(req, r.token), expires_at: r.expires_at });
  });
  route('POST', '/api/staff/clients/:id/users/:uid/link', 'staff', async ({ req, res, p, user }) => {
    const r = admin.newClientLink(db, { clientId: clientExists(int(p.id)), userId: int(p.uid), actor: user.email });
    send(res, 200, { link: inviteLink(req, r.token), expires_at: r.expires_at });
  });
  route('POST', '/api/staff/clients/:id/users/:uid/remove', 'staff', async ({ res, p, user }) => {
    admin.removeClientUser(db, { clientId: clientExists(int(p.id)), userId: int(p.uid), actor: user.email }); send(res, 200, { ok: true });
  });
  route('POST', '/api/invite/check', null, async ({ req, res }) => {
    const { token } = await readJson(req); const inv = auth.inviteInfo(db, token);
    if (!inv) throw new AppError(410, 'This link has expired or was already used. Ask your LeadG2 consultant for a new one.');
    send(res, 200, { name: inv.name, email: inv.email });
  });
  route('POST', '/api/invite/accept', null, async ({ req, res }) => {
    const r = auth.acceptInvite(db, await readJson(req));
    if (!r.ok) throw new AppError(400, r.error);
    send(res, 200, r);
  });

  // ---- LeadG2 team
  route('GET', '/api/staff/team', 'staff', ({ res, user }) => send(res, 200, { me: user.id, members: admin.listStaff(db) }));
  route('POST', '/api/staff/team', 'staff', async ({ req, res, user }) => {
    const b = await readJson(req); const r = admin.inviteStaff(db, { email: b.email, name: b.name, actor: user.email });
    send(res, 200, { userId: r.userId, link: inviteLink(req, r.token), expires_at: r.expires_at });
  });
  route('POST', '/api/staff/team/:uid/link', 'staff', async ({ req, res, p, user }) => {
    const r = admin.newStaffLink(db, { userId: int(p.uid), actor: user.email });
    send(res, 200, { link: inviteLink(req, r.token), expires_at: r.expires_at });
  });
  route('POST', '/api/staff/team/:uid/remove', 'staff', async ({ res, p, user }) => {
    admin.removeStaff(db, { userId: int(p.uid), actorId: user.id, actor: user.email }); send(res, 200, { ok: true });
  });

  // ---- clients (customers)
  route('GET', '/api/staff/clients-admin', 'staff', ({ res }) => send(res, 200, admin.listClientsAdmin(db)));
  route('POST', '/api/staff/clients', 'staff', async ({ req, res, user }) => {
    const b = await readJson(req); send(res, 200, admin.createClient(db, { ...b, actor: user.email }));
  });
  route('POST', '/api/staff/clients/:id', 'staff', async ({ req, res, p, user }) => {
    const id = clientExists(int(p.id)); const b = await readJson(req);
    admin.updateClient(db, { ...b, clientId: id, actor: user.email }); send(res, 200, { ok: true });
  });

  // ---- source mappings
  route('POST', '/api/staff/clients/:id/mappings', 'staff', async ({ req, res, p, user }) => {
    const id = clientExists(int(p.id)); const b = await readJson(req);
    send(res, 200, admin.addMapping(db, { clientId: id, sourceType: b.sourceType, value: b.value, scope: b.scope, label: b.label, actor: user.email }));
  });
  route('POST', '/api/staff/clients/:id/mappings/:mid/remove', 'staff', async ({ res, p, user }) => {
    admin.removeMapping(db, { clientId: clientExists(int(p.id)), mappingId: int(p.mid), actor: user.email }); send(res, 200, { ok: true });
  });

  route('GET', '/api/staff/match-queue', 'staff', ({ res }) => send(res, 200, ingest.matchQueue(db)));
  route('POST', '/api/staff/match-queue/:rid', 'staff', async ({ req, res, p, user }) => {
    const b = await readJson(req);
    if (b.clientId) clientExists(int(b.clientId));
    ingest.resolveMatch(db, { recordId: int(p.rid), clientId: b.clientId ? int(b.clientId) : null, actor: user.email, reason: b.reason });
    send(res, 200, { ok: true });
  });
  route('POST', '/api/staff/suggestions/:sid/:action', 'staff', async ({ req, res, p, user }) => {
    const id = int(p.sid); const b = await readJson(req); const actor = user.email;
    if (p.action === 'approve') return send(res, 200, review.approveSuggestion(db, { ...b, id, actor, points: b.points === '' || b.points == null ? null : Number(b.points) }));
    if (p.action === 'edit') return send(res, 200, review.editSuggestion(db, { ...b, id, actor, points: b.points === '' || b.points == null ? null : Number(b.points) }));
    if (p.action === 'dismiss') return send(res, 200, review.dismissSuggestion(db, { id, actor, reason: b.reason }));
    if (p.action === 'merge') return send(res, 200, review.mergeSuggestion(db, { id, intoId: int(b.intoId), actor, reason: b.reason }));
    throw new AppError(404, 'Unknown action');
  });
  route('POST', '/api/staff/work-items/:wid/:action', 'staff', async ({ req, res, p, user }) => {
    const id = int(p.wid); ownerOf('work_items', id); const b = await readJson(req); const actor = user.email;
    if (p.action === 'transition') return send(res, 200, ledger.transition(db, { itemId: id, to: b.to, actor, reason: b.reason, overrideReason: b.overrideReason }));
    if (p.action === 'correct') return send(res, 200, ledger.correct(db, { itemId: id, points: Number(b.points), actor, reason: b.reason, overrideReason: b.overrideReason }));
    if (p.action === 'summary') return send(res, 200, ledger.setSummary(db, { itemId: id, clientSummary: b.clientSummary, approved: !!b.approved, actor }));
    throw new AppError(404, 'Unknown action');
  });

  // ---- pages
  const pages = { '/': 'login.html', '/login': 'login.html', '/staff': 'staff.html', '/client': 'client.html', '/setup': 'setup.html' };

  return async function handler(req, res) {
    const url = new URL(req.url, 'http://localhost');
    try {
      if (req.method === 'GET' && pages[url.pathname]) return serveStatic(res, pages[url.pathname]);
      if (req.method === 'GET' && url.pathname.startsWith('/static/')) return serveStatic(res, url.pathname.slice(8));
      const token = parseCookies(req.headers.cookie)[COOKIE];
      for (const r of routes) {
        if (r.method !== req.method) continue;
        const m = r.re.exec(url.pathname); if (!m) continue;
        const p = Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
        const user = auth.userForToken(db, token);
        if (r.role && !user) throw new AppError(401, 'Sign in required');
        if (r.role && r.role !== 'any' && user.role !== r.role) throw new AppError(403, 'Not allowed');
        return await r.handler({ req, res, p, url, user, token });
      }
      send(res, 404, { error: 'Not found' });
    } catch (e) {
      const status = e.status || 500;
      if (status === 500) console.error(e);
      send(res, status, { error: status === 500 ? 'Internal error' : e.message });
    }
  };
}

if (require.main === module) {
  const db = openDb();
  if (!db.prepare(`SELECT 1 FROM users WHERE role = 'staff' LIMIT 1`).get()) {
    console.error('No admin accounts yet. Run `npm run create-admin -- you@leadg2.com "Your Name"` first (or `npm run demo` for sample data).');
    process.exit(1);
  }
  const port = Number(process.env.PORT || 3000);
  http.createServer(createApp({ db })).listen(port, () => console.log(`LeadG2 points tracker on http://localhost:${port}`));
}

module.exports = { createApp };
